import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Image,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { Droplets, Sun, Thermometer, Scissors, Bug, TriangleAlert as AlertTriangle, ChevronRight, Clock, BookOpen } from 'lucide-react-native';

const careGuides = [
  {
    id: 1,
    title: 'Watering Basics',
    description: 'Learn when and how to water your plants properly',
    icon: Droplets,
    color: '#3B82F6',
    readTime: '5 min read',
    image: 'https://images.pexels.com/photos/1301856/pexels-photo-1301856.jpeg',
  },
  {
    id: 2,
    title: 'Light Requirements',
    description: 'Understanding different light conditions for optimal growth',
    icon: Sun,
    color: '#F59E0B',
    readTime: '7 min read',
    image: 'https://images.pexels.com/photos/1005058/pexels-photo-1005058.jpeg',
  },
  {
    id: 3,
    title: 'Temperature & Humidity',
    description: 'Creating the perfect environment for your plants',
    icon: Thermometer,
    color: '#EF4444',
    readTime: '6 min read',
    image: 'https://images.pexels.com/photos/1084199/pexels-photo-1084199.jpeg',
  },
  {
    id: 4,
    title: 'Pruning & Maintenance',
    description: 'Keep your plants healthy with proper pruning techniques',
    icon: Scissors,
    color: '#10B981',
    readTime: '8 min read',
    image: 'https://images.pexels.com/photos/1301856/pexels-photo-1301856.jpeg',
  },
  {
    id: 5,
    title: 'Pest Control',
    description: 'Identify and treat common plant pests naturally',
    icon: Bug,
    color: '#8B5CF6',
    readTime: '10 min read',
    image: 'https://images.pexels.com/photos/1005058/pexels-photo-1005058.jpeg',
  },
  {
    id: 6,
    title: 'Common Problems',
    description: 'Troubleshoot yellowing leaves, root rot, and more',
    icon: AlertTriangle,
    color: '#F97316',
    readTime: '12 min read',
    image: 'https://images.pexels.com/photos/1084199/pexels-photo-1084199.jpeg',
  },
];

const quickTips = [
  {
    title: 'Check soil moisture',
    description: 'Stick your finger 1-2 inches into the soil to test moisture levels',
    icon: '💧',
  },
  {
    title: 'Rotate your plants',
    description: 'Turn plants weekly to ensure even growth and prevent leaning',
    icon: '🔄',
  },
  {
    title: 'Clean the leaves',
    description: 'Wipe leaves monthly to remove dust and improve photosynthesis',
    icon: '🧽',
  },
  {
    title: 'Watch for pests',
    description: 'Inspect plants regularly for signs of insects or disease',
    icon: '🔍',
  },
];

export default function GuideScreen() {
  const [selectedGuide, setSelectedGuide] = useState<number | null>(null);

  return (
    <SafeAreaView style={styles.container}>
      <LinearGradient
        colors={['#F0F9FF', '#E0F2FE']}
        style={styles.gradient}
      >
        <ScrollView style={styles.scrollView}>
          <View style={styles.header}>
            <Text style={styles.title}>Plant Care Guide</Text>
            <Text style={styles.subtitle}>
              Master the art of plant care with our comprehensive guides
            </Text>
          </View>
          
          <View style={styles.quickTipsSection}>
            <Text style={styles.sectionTitle}>Quick Tips</Text>
            <View style={styles.tipsGrid}>
              {quickTips.map((tip, index) => (
                <View key={index} style={styles.tipCard}>
                  <Text style={styles.tipIcon}>{tip.icon}</Text>
                  <Text style={styles.tipTitle}>{tip.title}</Text>
                  <Text style={styles.tipDescription}>{tip.description}</Text>
                </View>
              ))}
            </View>
          </View>
          
          <View style={styles.guidesSection}>
            <Text style={styles.sectionTitle}>Care Guides</Text>
            <View style={styles.guidesList}>
              {careGuides.map((guide) => (
                <TouchableOpacity
                  key={guide.id}
                  style={styles.guideCard}
                  onPress={() => setSelectedGuide(guide.id)}
                >
                  <Image source={{ uri: guide.image }} style={styles.guideImage} />
                  <View style={styles.guideContent}>
                    <View style={styles.guideHeader}>
                      <View style={[styles.iconContainer, { backgroundColor: guide.color + '20' }]}>
                        <guide.icon size={20} color={guide.color} />
                      </View>
                      <View style={styles.readTimeContainer}>
                        <Clock size={12} color="#6B7280" />
                        <Text style={styles.readTime}>{guide.readTime}</Text>
                      </View>
                    </View>
                    
                    <Text style={styles.guideTitle}>{guide.title}</Text>
                    <Text style={styles.guideDescription}>{guide.description}</Text>
                    
                    <View style={styles.guideFooter}>
                      <TouchableOpacity style={styles.readButton}>
                        <BookOpen size={16} color="#4F7942" />
                        <Text style={styles.readButtonText}>Read Guide</Text>
                        <ChevronRight size={16} color="#4F7942" />
                      </TouchableOpacity>
                    </View>
                  </View>
                </TouchableOpacity>
              ))}
            </View>
          </View>
          
          <View style={styles.emergencySection}>
            <View style={styles.emergencyCard}>
              <View style={styles.emergencyHeader}>
                <AlertTriangle size={24} color="#EF4444" />
                <Text style={styles.emergencyTitle}>Plant Emergency?</Text>
              </View>
              <Text style={styles.emergencyDescription}>
                If your plant is showing signs of distress, use our quick diagnosis tool to identify the problem and get immediate help.
              </Text>
              <TouchableOpacity style={styles.emergencyButton}>
                <Text style={styles.emergencyButtonText}>Quick Diagnosis</Text>
              </TouchableOpacity>
            </View>
          </View>
        </ScrollView>
      </LinearGradient>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFFFFF',
  },
  gradient: {
    flex: 1,
  },
  scrollView: {
    flex: 1,
  },
  header: {
    paddingHorizontal: 20,
    paddingTop: 20,
    paddingBottom: 24,
  },
  title: {
    fontSize: 32,
    fontFamily: 'Playfair-Bold',
    color: '#1F2937',
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
    lineHeight: 24,
  },
  quickTipsSection: {
    paddingHorizontal: 20,
    marginBottom: 32,
  },
  sectionTitle: {
    fontSize: 24,
    fontFamily: 'Playfair-SemiBold',
    color: '#1F2937',
    marginBottom: 16,
  },
  tipsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  tipCard: {
    backgroundColor: '#FFFFFF',
    padding: 16,
    borderRadius: 12,
    width: '48%',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  tipIcon: {
    fontSize: 24,
    marginBottom: 8,
  },
  tipTitle: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: '#1F2937',
    marginBottom: 4,
  },
  tipDescription: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
    lineHeight: 16,
  },
  guidesSection: {
    paddingHorizontal: 20,
    marginBottom: 32,
  },
  guidesList: {
    gap: 16,
  },
  guideCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
  },
  guideImage: {
    width: '100%',
    height: 160,
    resizeMode: 'cover',
  },
  guideContent: {
    padding: 16,
  },
  guideHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  iconContainer: {
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
  },
  readTimeContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  readTime: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
  },
  guideTitle: {
    fontSize: 18,
    fontFamily: 'Playfair-SemiBold',
    color: '#1F2937',
    marginBottom: 8,
  },
  guideDescription: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
    lineHeight: 20,
    marginBottom: 16,
  },
  guideFooter: {
    alignItems: 'flex-start',
  },
  readButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  readButtonText: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: '#4F7942',
  },
  emergencySection: {
    paddingHorizontal: 20,
    paddingBottom: 20,
  },
  emergencyCard: {
    backgroundColor: '#FEF2F2',
    padding: 20,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: '#FECACA',
  },
  emergencyHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    marginBottom: 12,
  },
  emergencyTitle: {
    fontSize: 18,
    fontFamily: 'Playfair-SemiBold',
    color: '#1F2937',
  },
  emergencyDescription: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
    lineHeight: 20,
    marginBottom: 16,
  },
  emergencyButton: {
    backgroundColor: '#EF4444',
    paddingVertical: 12,
    paddingHorizontal: 20,
    borderRadius: 8,
    alignSelf: 'flex-start',
  },
  emergencyButtonText: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: '#FFFFFF',
  },
});