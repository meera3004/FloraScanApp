import React, { useState, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Image,
  ScrollView,
  Dimensions,
  Alert,
} from 'react-native';
import { CameraView, CameraType, useCameraPermissions } from 'expo-camera';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import {
  Camera,
  Image as ImageIcon,
  FlipHorizontal,
  Zap,
  Sparkles,
  X,
  Leaf,
} from 'lucide-react-native';

const { width, height } = Dimensions.get('window');

export default function IdentifyScreen() {
  const [facing, setFacing] = useState<CameraType>('back');
  const [permission, requestPermission] = useCameraPermissions();
  const [showCamera, setShowCamera] = useState(false);
  const [capturedImage, setCapturedImage] = useState<string | null>(null);
  const [isIdentifying, setIsIdentifying] = useState(false);
  const [identificationResult, setIdentificationResult] = useState<any>(null);
  const cameraRef = useRef<CameraView>(null);

  const toggleCameraFacing = () => {
    setFacing(current => (current === 'back' ? 'front' : 'back'));
  };

  const openCamera = async () => {
    if (!permission?.granted) {
      const result = await requestPermission();
      if (!result.granted) {
        Alert.alert('Permission needed', 'Camera permission is required to identify plants');
        return;
      }
    }
    setShowCamera(true);
  };

  const takePicture = async () => {
    if (cameraRef.current) {
      try {
        const photo = await cameraRef.current.takePictureAsync({
          quality: 0.8,
          base64: false,
        });
        setCapturedImage(photo.uri);
        setShowCamera(false);
        identifyPlant(photo.uri);
      } catch (error) {
        Alert.alert('Error', 'Failed to take picture');
      }
    }
  };

  const identifyPlant = async (imageUri: string) => {
    setIsIdentifying(true);
    
    // Simulate AI identification process
    setTimeout(() => {
      const mockResult = {
        name: 'Monstera Deliciosa',
        commonName: 'Swiss Cheese Plant',
        confidence: 95,
        family: 'Araceae',
        origin: 'Central America',
        careLevel: 'Easy',
        toxicity: 'Toxic to pets',
        description: 'A popular houseplant known for its distinctive split leaves and easy care requirements.',
        careInstructions: {
          light: 'Bright, indirect light',
          water: 'Water when top inch of soil is dry',
          humidity: '40-60%',
          temperature: '65-80°F (18-27°C)',
        },
      };
      
      setIdentificationResult(mockResult);
      setIsIdentifying(false);
    }, 2000);
  };

  const resetIdentification = () => {
    setCapturedImage(null);
    setIdentificationResult(null);
    setIsIdentifying(false);
  };

  if (showCamera) {
    return (
      <View style={styles.cameraContainer}>
        <CameraView
          ref={cameraRef}
          style={styles.camera}
          facing={facing}
        >
          <SafeAreaView style={styles.cameraOverlay}>
            <View style={styles.cameraHeader}>
              <TouchableOpacity
                style={styles.closeButton}
                onPress={() => setShowCamera(false)}
              >
                <X size={24} color="#FFFFFF" />
              </TouchableOpacity>
              <Text style={styles.cameraTitle}>Position plant in frame</Text>
              <TouchableOpacity
                style={styles.flipButton}
                onPress={toggleCameraFacing}
              >
                <FlipHorizontal size={24} color="#FFFFFF" />
              </TouchableOpacity>
            </View>
            
            <View style={styles.cameraFrame}>
              <View style={styles.frameCorner} />
              <View style={[styles.frameCorner, styles.frameCornerTopRight]} />
              <View style={[styles.frameCorner, styles.frameCornerBottomLeft]} />
              <View style={[styles.frameCorner, styles.frameCornerBottomRight]} />
            </View>
            
            <View style={styles.cameraFooter}>
              <TouchableOpacity
                style={styles.captureButton}
                onPress={takePicture}
              >
                <View style={styles.captureButtonInner} />
              </TouchableOpacity>
            </View>
          </SafeAreaView>
        </CameraView>
      </View>
    );
  }

  if (capturedImage && (isIdentifying || identificationResult)) {
    return (
      <SafeAreaView style={styles.container}>
        <ScrollView style={styles.resultContainer}>
          <View style={styles.resultHeader}>
            <TouchableOpacity
              style={styles.backButton}
              onPress={resetIdentification}
            >
              <X size={24} color="#4F7942" />
            </TouchableOpacity>
            <Text style={styles.resultTitle}>Plant Identification</Text>
          </View>
          
          <Image source={{ uri: capturedImage }} style={styles.resultImage} />
          
          {isIdentifying ? (
            <View style={styles.loadingContainer}>
              <Sparkles size={32} color="#4F7942" />
              <Text style={styles.loadingText}>Analyzing your plant...</Text>
              <Text style={styles.loadingSubtext}>This may take a few seconds</Text>
            </View>
          ) : identificationResult ? (
            <View style={styles.resultContent}>
              <View style={styles.confidenceContainer}>
                <Text style={styles.confidenceText}>
                  {identificationResult.confidence}% Match
                </Text>
              </View>
              
              <Text style={styles.plantName}>{identificationResult.name}</Text>
              <Text style={styles.commonName}>{identificationResult.commonName}</Text>
              
              <Text style={styles.description}>{identificationResult.description}</Text>
              
              <View style={styles.infoGrid}>
                <View style={styles.infoCard}>
                  <Text style={styles.infoLabel}>Family</Text>
                  <Text style={styles.infoValue}>{identificationResult.family}</Text>
                </View>
                <View style={styles.infoCard}>
                  <Text style={styles.infoLabel}>Origin</Text>
                  <Text style={styles.infoValue}>{identificationResult.origin}</Text>
                </View>
                <View style={styles.infoCard}>
                  <Text style={styles.infoLabel}>Care Level</Text>
                  <Text style={styles.infoValue}>{identificationResult.careLevel}</Text>
                </View>
                <View style={styles.infoCard}>
                  <Text style={styles.infoLabel}>Pet Safety</Text>
                  <Text style={[styles.infoValue, styles.toxicityText]}>
                    {identificationResult.toxicity}
                  </Text>
                </View>
              </View>
              
              <View style={styles.careSection}>
                <Text style={styles.careTitle}>Care Instructions</Text>
                {Object.entries(identificationResult.careInstructions).map(([key, value]) => (
                  <View key={key} style={styles.careItem}>
                    <Text style={styles.careLabel}>{key.charAt(0).toUpperCase() + key.slice(1)}:</Text>
                    <Text style={styles.careValue}>{value as string}</Text>
                  </View>
                ))}
              </View>
              
              <TouchableOpacity style={styles.saveButton}>
                <Text style={styles.saveButtonText}>Save to Collection</Text>
              </TouchableOpacity>
            </View>
          ) : null}
        </ScrollView>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <LinearGradient
        colors={['#F0F9FF', '#E0F2FE']}
        style={styles.gradient}
      >
        <ScrollView contentContainerStyle={styles.scrollContent}>
          <View style={styles.header}>
            <Image
              source={{ uri: '/assets/images/TRYxyFbI.jpg' }}
              style={styles.logo}
            />
            <Text style={styles.title}>FloraScan</Text>
            <Text style={styles.subtitle}>Your Smart Plant Identifier</Text>
          </View>
          
          <View style={styles.heroSection}>
            <Text style={styles.heroTitle}>Discover Nature's Secrets</Text>
            <Text style={styles.heroSubtitle}>
              Instantly identify any plant, flower, or tree with AI-powered precision
            </Text>
          </View>
          
          <View style={styles.actionContainer}>
            <TouchableOpacity style={styles.primaryButton} onPress={openCamera}>
              <Camera size={24} color="#FFFFFF" />
              <Text style={styles.primaryButtonText}>Take Photo</Text>
            </TouchableOpacity>
            
            <TouchableOpacity style={styles.secondaryButton}>
              <ImageIcon size={24} color="#4F7942" />
              <Text style={styles.secondaryButtonText}>Choose from Gallery</Text>
            </TouchableOpacity>
          </View>
          
          <View style={styles.featuresContainer}>
            <Text style={styles.featuresTitle}>Why Choose FloraScan?</Text>
            
            <View style={styles.featuresList}>
              <View style={styles.featureItem}>
                <Zap size={20} color="#4F7942" />
                <View style={styles.featureContent}>
                  <Text style={styles.featureTitle}>Instant Recognition</Text>
                  <Text style={styles.featureDescription}>
                    Get accurate plant identification in seconds
                  </Text>
                </View>
              </View>
              
              <View style={styles.featureItem}>
                <Sparkles size={20} color="#4F7942" />
                <View style={styles.featureContent}>
                  <Text style={styles.featureTitle}>AI-Powered</Text>
                  <Text style={styles.featureDescription}>
                    Advanced machine learning for precise results
                  </Text>
                </View>
              </View>
              
              <View style={styles.featureItem}>
                <Leaf size={20} color="#4F7942" />
                <View style={styles.featureContent}>
                  <Text style={styles.featureTitle}>Comprehensive Database</Text>
                  <Text style={styles.featureDescription}>
                    Thousands of species from around the world
                  </Text>
                </View>
              </View>
            </View>
          </View>
        </ScrollView>
      </LinearGradient>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFFFFF',
  },
  gradient: {
    flex: 1,
  },
  scrollContent: {
    flexGrow: 1,
    paddingHorizontal: 20,
  },
  header: {
    alignItems: 'center',
    paddingTop: 20,
    paddingBottom: 30,
  },
  logo: {
    width: 80,
    height: 80,
    borderRadius: 40,
    marginBottom: 16,
  },
  title: {
    fontSize: 32,
    fontFamily: 'Playfair-Bold',
    color: '#1F2937',
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 16,
    fontFamily: 'Inter-Medium',
    color: '#6B7280',
  },
  heroSection: {
    alignItems: 'center',
    paddingVertical: 30,
  },
  heroTitle: {
    fontSize: 28,
    fontFamily: 'Playfair-SemiBold',
    color: '#1F2937',
    textAlign: 'center',
    marginBottom: 12,
  },
  heroSubtitle: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
    textAlign: 'center',
    lineHeight: 24,
  },
  actionContainer: {
    paddingVertical: 30,
    gap: 16,
  },
  primaryButton: {
    backgroundColor: '#4F7942',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 16,
    paddingHorizontal: 24,
    borderRadius: 16,
    gap: 12,
  },
  primaryButtonText: {
    fontSize: 18,
    fontFamily: 'Inter-SemiBold',
    color: '#FFFFFF',
  },
  secondaryButton: {
    backgroundColor: '#FFFFFF',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 16,
    paddingHorizontal: 24,
    borderRadius: 16,
    borderWidth: 2,
    borderColor: '#4F7942',
    gap: 12,
  },
  secondaryButtonText: {
    fontSize: 18,
    fontFamily: 'Inter-SemiBold',
    color: '#4F7942',
  },
  featuresContainer: {
    paddingVertical: 30,
  },
  featuresTitle: {
    fontSize: 24,
    fontFamily: 'Playfair-SemiBold',
    color: '#1F2937',
    textAlign: 'center',
    marginBottom: 24,
  },
  featuresList: {
    gap: 20,
  },
  featureItem: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 16,
    backgroundColor: '#FFFFFF',
    padding: 20,
    borderRadius: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 3,
  },
  featureContent: {
    flex: 1,
  },
  featureTitle: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#1F2937',
    marginBottom: 4,
  },
  featureDescription: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
    lineHeight: 20,
  },
  cameraContainer: {
    flex: 1,
  },
  camera: {
    flex: 1,
  },
  cameraOverlay: {
    flex: 1,
    backgroundColor: 'transparent',
  },
  cameraHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingTop: 20,
  },
  closeButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  cameraTitle: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#FFFFFF',
    textAlign: 'center',
  },
  flipButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  cameraFrame: {
    flex: 1,
    margin: 40,
    position: 'relative',
  },
  frameCorner: {
    position: 'absolute',
    width: 30,
    height: 30,
    borderColor: '#FFFFFF',
    borderWidth: 3,
    top: 0,
    left: 0,
    borderRightWidth: 0,
    borderBottomWidth: 0,
  },
  frameCornerTopRight: {
    top: 0,
    right: 0,
    left: 'auto',
    borderLeftWidth: 0,
    borderRightWidth: 3,
  },
  frameCornerBottomLeft: {
    bottom: 0,
    top: 'auto',
    borderTopWidth: 3,
    borderBottomWidth: 0,
  },
  frameCornerBottomRight: {
    bottom: 0,
    right: 0,
    top: 'auto',
    left: 'auto',
    borderLeftWidth: 0,
    borderRightWidth: 3,
    borderTopWidth: 3,
    borderBottomWidth: 0,
  },
  cameraFooter: {
    alignItems: 'center',
    paddingBottom: 40,
  },
  captureButton: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: '#FFFFFF',
    alignItems: 'center',
    justifyContent: 'center',
  },
  captureButtonInner: {
    width: 60,
    height: 60,
    borderRadius: 30,
    backgroundColor: '#4F7942',
  },
  resultContainer: {
    flex: 1,
  },
  resultHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#E5E7EB',
  },
  backButton: {
    marginRight: 16,
  },
  resultTitle: {
    fontSize: 18,
    fontFamily: 'Inter-SemiBold',
    color: '#1F2937',
  },
  resultImage: {
    width: width,
    height: 300,
    resizeMode: 'cover',
  },
  loadingContainer: {
    alignItems: 'center',
    paddingVertical: 40,
  },
  loadingText: {
    fontSize: 18,
    fontFamily: 'Inter-SemiBold',
    color: '#1F2937',
    marginTop: 16,
  },
  loadingSubtext: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
    marginTop: 8,
  },
  resultContent: {
    padding: 20,
  },
  confidenceContainer: {
    alignSelf: 'flex-start',
    backgroundColor: '#10B981',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 20,
    marginBottom: 16,
  },
  confidenceText: {
    fontSize: 12,
    fontFamily: 'Inter-SemiBold',
    color: '#FFFFFF',
  },
  plantName: {
    fontSize: 28,
    fontFamily: 'Playfair-Bold',
    color: '#1F2937',
    marginBottom: 8,
  },
  commonName: {
    fontSize: 18,
    fontFamily: 'Inter-Medium',
    color: '#6B7280',
    marginBottom: 16,
  },
  description: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#374151',
    lineHeight: 24,
    marginBottom: 24,
  },
  infoGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
    marginBottom: 24,
  },
  infoCard: {
    flex: 1,
    minWidth: '45%',
    backgroundColor: '#F9FAFB',
    padding: 16,
    borderRadius: 12,
  },
  infoLabel: {
    fontSize: 12,
    fontFamily: 'Inter-Medium',
    color: '#6B7280',
    marginBottom: 4,
  },
  infoValue: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: '#1F2937',
  },
  toxicityText: {
    color: '#DC2626',
  },
  careSection: {
    marginBottom: 24,
  },
  careTitle: {
    fontSize: 20,
    fontFamily: 'Playfair-SemiBold',
    color: '#1F2937',
    marginBottom: 16,
  },
  careItem: {
    flexDirection: 'row',
    marginBottom: 12,
  },
  careLabel: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: '#374151',
    width: 80,
  },
  careValue: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
    flex: 1,
  },
  saveButton: {
    backgroundColor: '#4F7942',
    paddingVertical: 16,
    borderRadius: 12,
    alignItems: 'center',
  },
  saveButtonText: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#FFFFFF',
  },
});