import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Image,
  TextInput,
  FlatList,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { Search, Filter, Star, MapPin } from 'lucide-react-native';

const categories = [
  { id: 'all', name: 'All Plants', count: 2847 },
  { id: 'houseplants', name: 'Houseplants', count: 456 },
  { id: 'flowers', name: 'Flowers', count: 892 },
  { id: 'trees', name: 'Trees', count: 634 },
  { id: 'succulents', name: 'Succulents', count: 287 },
  { id: 'herbs', name: 'Herbs', count: 156 },
];

const featuredPlants = [
  {
    id: 1,
    name: 'Monstera Deliciosa',
    commonName: 'Swiss Cheese Plant',
    image: 'https://images.pexels.com/photos/6208086/pexels-photo-6208086.jpeg',
    difficulty: 'Easy',
    rating: 4.8,
    origin: 'Central America',
  },
  {
    id: 2,
    name: 'Fiddle Leaf Fig',
    commonName: 'Ficus Lyrata',
    image: 'https://images.pexels.com/photos/6208087/pexels-photo-6208087.jpeg',
    difficulty: 'Medium',
    rating: 4.6,
    origin: 'West Africa',
  },
  {
    id: 3,
    name: 'Snake Plant',
    commonName: 'Sansevieria',
    image: 'https://images.pexels.com/photos/2123482/pexels-photo-2123482.jpeg',
    difficulty: 'Easy',
    rating: 4.9,
    origin: 'West Africa',
  },
  {
    id: 4,
    name: 'Peace Lily',
    commonName: 'Spathiphyllum',
    image: 'https://images.pexels.com/photos/4503821/pexels-photo-4503821.jpeg',
    difficulty: 'Easy',
    rating: 4.7,
    origin: 'Tropical Americas',
  },
];

const popularSearches = [
  'Monstera', 'Pothos', 'Snake Plant', 'Fiddle Leaf Fig', 'Peace Lily', 'Rubber Plant'
];

export default function DiscoverScreen() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');

  const renderPlantCard = ({ item }: { item: typeof featuredPlants[0] }) => (
    <TouchableOpacity style={styles.plantCard}>
      <Image source={{ uri: item.image }} style={styles.plantImage} />
      <View style={styles.plantInfo}>
        <Text style={styles.plantName}>{item.name}</Text>
        <Text style={styles.commonName}>{item.commonName}</Text>
        
        <View style={styles.plantMeta}>
          <View style={styles.ratingContainer}>
            <Star size={14} color="#F59E0B" fill="#F59E0B" />
            <Text style={styles.rating}>{item.rating}</Text>
          </View>
          <View style={styles.difficultyContainer}>
            <Text style={[
              styles.difficulty,
              item.difficulty === 'Easy' ? styles.difficultyEasy : styles.difficultyMedium
            ]}>
              {item.difficulty}
            </Text>
          </View>
        </View>
        
        <View style={styles.originContainer}>
          <MapPin size={12} color="#6B7280" />
          <Text style={styles.origin}>{item.origin}</Text>
        </View>
      </View>
    </TouchableOpacity>
  );

  return (
    <SafeAreaView style={styles.container}>
      <LinearGradient
        colors={['#F0F9FF', '#E0F2FE']}
        style={styles.gradient}
      >
        <ScrollView style={styles.scrollView}>
          <View style={styles.header}>
            <Text style={styles.title}>Discover Plants</Text>
            <Text style={styles.subtitle}>Explore our comprehensive plant database</Text>
          </View>
          
          <View style={styles.searchContainer}>
            <View style={styles.searchInputContainer}>
              <Search size={20} color="#6B7280" />
              <TextInput
                style={styles.searchInput}
                placeholder="Search plants, flowers, trees..."
                value={searchQuery}
                onChangeText={setSearchQuery}
                placeholderTextColor="#9CA3AF"
              />
            </View>
            <TouchableOpacity style={styles.filterButton}>
              <Filter size={20} color="#4F7942" />
            </TouchableOpacity>
          </View>
          
          {searchQuery === '' && (
            <View style={styles.popularSearches}>
              <Text style={styles.sectionTitle}>Popular Searches</Text>
              <View style={styles.tagsContainer}>
                {popularSearches.map((tag, index) => (
                  <TouchableOpacity
                    key={index}
                    style={styles.tag}
                    onPress={() => setSearchQuery(tag)}
                  >
                    <Text style={styles.tagText}>{tag}</Text>
                  </TouchableOpacity>
                ))}
              </View>
            </View>
          )}
          
          <View style={styles.categoriesContainer}>
            <Text style={styles.sectionTitle}>Categories</Text>
            <ScrollView horizontal showsHorizontalScrollIndicator={false}>
              <View style={styles.categoriesList}>
                {categories.map((category) => (
                  <TouchableOpacity
                    key={category.id}
                    style={[
                      styles.categoryCard,
                      selectedCategory === category.id && styles.categoryCardActive
                    ]}
                    onPress={() => setSelectedCategory(category.id)}
                  >
                    <Text style={[
                      styles.categoryName,
                      selectedCategory === category.id && styles.categoryNameActive
                    ]}>
                      {category.name}
                    </Text>
                    <Text style={[
                      styles.categoryCount,
                      selectedCategory === category.id && styles.categoryCountActive
                    ]}>
                      {category.count} plants
                    </Text>
                  </TouchableOpacity>
                ))}
              </View>
            </ScrollView>
          </View>
          
          <View style={styles.featuredSection}>
            <Text style={styles.sectionTitle}>Featured Plants</Text>
            <FlatList
              data={featuredPlants}
              renderItem={renderPlantCard}
              keyExtractor={(item) => item.id.toString()}
              numColumns={2}
              columnWrapperStyle={styles.row}
              scrollEnabled={false}
            />
          </View>
        </ScrollView>
      </LinearGradient>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFFFFF',
  },
  gradient: {
    flex: 1,
  },
  scrollView: {
    flex: 1,
  },
  header: {
    paddingHorizontal: 20,
    paddingTop: 20,
    paddingBottom: 24,
  },
  title: {
    fontSize: 32,
    fontFamily: 'Playfair-Bold',
    color: '#1F2937',
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
  },
  searchContainer: {
    flexDirection: 'row',
    paddingHorizontal: 20,
    marginBottom: 24,
    gap: 12,
  },
  searchInputContainer: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderRadius: 12,
    gap: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  searchInput: {
    flex: 1,
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#1F2937',
  },
  filterButton: {
    backgroundColor: '#FFFFFF',
    padding: 12,
    borderRadius: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  popularSearches: {
    paddingHorizontal: 20,
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 20,
    fontFamily: 'Playfair-SemiBold',
    color: '#1F2937',
    marginBottom: 16,
  },
  tagsContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  },
  tag: {
    backgroundColor: '#FFFFFF',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: '#E5E7EB',
  },
  tagText: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#4F7942',
  },
  categoriesContainer: {
    marginBottom: 24,
  },
  categoriesList: {
    flexDirection: 'row',
    paddingHorizontal: 20,
    gap: 12,
  },
  categoryCard: {
    backgroundColor: '#FFFFFF',
    paddingHorizontal: 20,
    paddingVertical: 16,
    borderRadius: 12,
    minWidth: 120,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  categoryCardActive: {
    backgroundColor: '#4F7942',
  },
  categoryName: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: '#1F2937',
    marginBottom: 4,
  },
  categoryNameActive: {
    color: '#FFFFFF',
  },
  categoryCount: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
  },
  categoryCountActive: {
    color: '#E5E7EB',
  },
  featuredSection: {
    paddingHorizontal: 20,
    paddingBottom: 20,
  },
  row: {
    justifyContent: 'space-between',
  },
  plantCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    overflow: 'hidden',
    width: '48%',
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
  },
  plantImage: {
    width: '100%',
    height: 120,
    resizeMode: 'cover',
  },
  plantInfo: {
    padding: 12,
  },
  plantName: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: '#1F2937',
    marginBottom: 2,
  },
  commonName: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
    marginBottom: 8,
  },
  plantMeta: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  ratingContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  rating: {
    fontSize: 12,
    fontFamily: 'Inter-Medium',
    color: '#1F2937',
  },
  difficultyContainer: {
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: 8,
  },
  difficulty: {
    fontSize: 10,
    fontFamily: 'Inter-SemiBold',
  },
  difficultyEasy: {
    color: '#10B981',
    backgroundColor: '#D1FAE5',
  },
  difficultyMedium: {
    color: '#F59E0B',
    backgroundColor: '#FEF3C7',
  },
  originContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  origin: {
    fontSize: 10,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
  },
});