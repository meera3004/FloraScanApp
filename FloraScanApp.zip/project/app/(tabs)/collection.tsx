import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Image,
  FlatList,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { Heart, Plus, Calendar, MapPin, Star, Grid3x3 as Grid3X3, List, Search, Filter } from 'lucide-react-native';

const myPlants = [
  {
    id: 1,
    name: 'Monstera Deliciosa',
    commonName: 'Swiss Cheese Plant',
    image: 'https://images.pexels.com/photos/6208086/pexels-photo-6208086.jpeg',
    dateAdded: '2024-01-15',
    location: 'Living Room',
    rating: 5,
    notes: 'Growing beautifully! New leaf unfurling.',
    lastWatered: '2024-01-20',
  },
  {
    id: 2,
    name: 'Fiddle Leaf Fig',
    commonName: 'Ficus Lyrata',
    image: 'https://images.pexels.com/photos/6208087/pexels-photo-6208087.jpeg',
    dateAdded: '2024-01-10',
    location: 'Bedroom',
    rating: 4,
    notes: 'Needs more humidity. Added humidifier nearby.',
    lastWatered: '2024-01-18',
  },
  {
    id: 3,
    name: 'Snake Plant',
    commonName: 'Sansevieria',
    image: 'https://images.pexels.com/photos/2123482/pexels-photo-2123482.jpeg',
    dateAdded: '2024-01-05',
    location: 'Office',
    rating: 5,
    notes: 'Perfect low-light plant. Very low maintenance.',
    lastWatered: '2024-01-12',
  },
  {
    id: 4,
    name: 'Peace Lily',
    commonName: 'Spathiphyllum',
    image: 'https://images.pexels.com/photos/4503821/pexels-photo-4503821.jpeg',
    dateAdded: '2024-01-08',
    location: 'Bathroom',
    rating: 4,
    notes: 'Loves the humidity here. Blooming regularly.',
    lastWatered: '2024-01-19',
  },
];

const stats = [
  { label: 'Plants Identified', value: '47', icon: Search },
  { label: 'In Collection', value: '12', icon: Heart },
  { label: 'Care Reminders', value: '3', icon: Calendar },
  { label: 'Avg Rating', value: '4.6', icon: Star },
];

export default function CollectionScreen() {
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [selectedFilter, setSelectedFilter] = useState('all');

  const renderPlantCard = ({ item }: { item: typeof myPlants[0] }) => {
    if (viewMode === 'grid') {
      return (
        <TouchableOpacity style={styles.gridCard}>
          <Image source={{ uri: item.image }} style={styles.gridImage} />
          <View style={styles.gridContent}>
            <Text style={styles.gridName} numberOfLines={1}>{item.name}</Text>
            <Text style={styles.gridCommonName} numberOfLines={1}>{item.commonName}</Text>
            <View style={styles.gridMeta}>
              <View style={styles.ratingContainer}>
                <Star size={12} color="#F59E0B" fill="#F59E0B" />
                <Text style={styles.rating}>{item.rating}</Text>
              </View>
              <View style={styles.locationContainer}>
                <MapPin size={10} color="#6B7280" />
                <Text style={styles.location} numberOfLines={1}>{item.location}</Text>
              </View>
            </View>
          </View>
        </TouchableOpacity>
      );
    }

    return (
      <TouchableOpacity style={styles.listCard}>
        <Image source={{ uri: item.image }} style={styles.listImage} />
        <View style={styles.listContent}>
          <Text style={styles.listName}>{item.name}</Text>
          <Text style={styles.listCommonName}>{item.commonName}</Text>
          <View style={styles.listMeta}>
            <View style={styles.metaItem}>
              <Calendar size={12} color="#6B7280" />
              <Text style={styles.metaText}>Added {item.dateAdded}</Text>
            </View>
            <View style={styles.metaItem}>
              <MapPin size={12} color="#6B7280" />
              <Text style={styles.metaText}>{item.location}</Text>
            </View>
          </View>
          <Text style={styles.notes} numberOfLines={2}>{item.notes}</Text>
        </View>
        <View style={styles.listActions}>
          <View style={styles.ratingContainer}>
            <Star size={14} color="#F59E0B" fill="#F59E0B" />
            <Text style={styles.rating}>{item.rating}</Text>
          </View>
          <TouchableOpacity style={styles.favoriteButton}>
            <Heart size={16} color="#EF4444" fill="#EF4444" />
          </TouchableOpacity>
        </View>
      </TouchableOpacity>
    );
  };

  return (
    <SafeAreaView style={styles.container}>
      <LinearGradient
        colors={['#F0F9FF', '#E0F2FE']}
        style={styles.gradient}
      >
        <ScrollView style={styles.scrollView}>
          <View style={styles.header}>
            <Text style={styles.title}>My Collection</Text>
            <Text style={styles.subtitle}>Track and care for your beloved plants</Text>
          </View>
          
          <View style={styles.statsContainer}>
            <View style={styles.statsGrid}>
              {stats.map((stat, index) => (
                <View key={index} style={styles.statCard}>
                  <stat.icon size={20} color="#4F7942" />
                  <Text style={styles.statValue}>{stat.value}</Text>
                  <Text style={styles.statLabel}>{stat.label}</Text>
                </View>
              ))}
            </View>
          </View>
          
          <View style={styles.controlsContainer}>
            <View style={styles.viewControls}>
              <TouchableOpacity
                style={[styles.viewButton, viewMode === 'grid' && styles.viewButtonActive]}
                onPress={() => setViewMode('grid')}
              >
                <Grid3X3 size={16} color={viewMode === 'grid' ? '#FFFFFF' : '#6B7280'} />
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.viewButton, viewMode === 'list' && styles.viewButtonActive]}
                onPress={() => setViewMode('list')}
              >
                <List size={16} color={viewMode === 'list' ? '#FFFFFF' : '#6B7280'} />
              </TouchableOpacity>
            </View>
            
            <TouchableOpacity style={styles.filterButton}>
              <Filter size={16} color="#4F7942" />
              <Text style={styles.filterText}>Filter</Text>
            </TouchableOpacity>
          </View>
          
          <View style={styles.plantsContainer}>
            <View style={styles.sectionHeader}>
              <Text style={styles.sectionTitle}>My Plants ({myPlants.length})</Text>
              <TouchableOpacity style={styles.addButton}>
                <Plus size={16} color="#4F7942" />
                <Text style={styles.addButtonText}>Add Plant</Text>
              </TouchableOpacity>
            </View>
            
            <FlatList
              data={myPlants}
              renderItem={renderPlantCard}
              keyExtractor={(item) => item.id.toString()}
              numColumns={viewMode === 'grid' ? 2 : 1}
              key={viewMode}
              columnWrapperStyle={viewMode === 'grid' ? styles.row : undefined}
              scrollEnabled={false}
              contentContainerStyle={styles.plantsList}
            />
          </View>
          
          <View style={styles.careReminders}>
            <Text style={styles.sectionTitle}>Care Reminders</Text>
            <View style={styles.reminderCard}>
              <View style={styles.reminderIcon}>
                <Calendar size={20} color="#3B82F6" />
              </View>
              <View style={styles.reminderContent}>
                <Text style={styles.reminderTitle}>Water your Snake Plant</Text>
                <Text style={styles.reminderTime}>Due in 2 days</Text>
              </View>
              <TouchableOpacity style={styles.reminderAction}>
                <Text style={styles.reminderActionText}>Mark Done</Text>
              </TouchableOpacity>
            </View>
            
            <View style={styles.reminderCard}>
              <View style={styles.reminderIcon}>
                <Calendar size={20} color="#F59E0B" />
              </View>
              <View style={styles.reminderContent}>
                <Text style={styles.reminderTitle}>Fertilize Monstera</Text>
                <Text style={styles.reminderTime}>Due tomorrow</Text>
              </View>
              <TouchableOpacity style={styles.reminderAction}>
                <Text style={styles.reminderActionText}>Mark Done</Text>
              </TouchableOpacity>
            </View>
          </View>
        </ScrollView>
      </LinearGradient>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFFFFF',
  },
  gradient: {
    flex: 1,
  },
  scrollView: {
    flex: 1,
  },
  header: {
    paddingHorizontal: 20,
    paddingTop: 20,
    paddingBottom: 24,
  },
  title: {
    fontSize: 32,
    fontFamily: 'Playfair-Bold',
    color: '#1F2937',
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
  },
  statsContainer: {
    paddingHorizontal: 20,
    marginBottom: 24,
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  statCard: {
    backgroundColor: '#FFFFFF',
    padding: 16,
    borderRadius: 12,
    width: '48%',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  statValue: {
    fontSize: 24,
    fontFamily: 'Playfair-Bold',
    color: '#1F2937',
    marginTop: 8,
    marginBottom: 4,
  },
  statLabel: {
    fontSize: 12,
    fontFamily: 'Inter-Medium',
    color: '#6B7280',
    textAlign: 'center',
  },
  controlsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    marginBottom: 20,
  },
  viewControls: {
    flexDirection: 'row',
    backgroundColor: '#FFFFFF',
    borderRadius: 8,
    padding: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  viewButton: {
    padding: 8,
    borderRadius: 6,
  },
  viewButtonActive: {
    backgroundColor: '#4F7942',
  },
  filterButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 8,
    gap: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  filterText: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#4F7942',
  },
  plantsContainer: {
    paddingHorizontal: 20,
    marginBottom: 24,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  sectionTitle: {
    fontSize: 20,
    fontFamily: 'Playfair-SemiBold',
    color: '#1F2937',
  },
  addButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 8,
    gap: 6,
    borderWidth: 1,
    borderColor: '#4F7942',
  },
  addButtonText: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#4F7942',
  },
  plantsList: {
    gap: 12,
  },
  row: {
    justifyContent: 'space-between',
  },
  gridCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    overflow: 'hidden',
    width: '48%',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  gridImage: {
    width: '100%',
    height: 120,
    resizeMode: 'cover',
  },
  gridContent: {
    padding: 12,
  },
  gridName: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: '#1F2937',
    marginBottom: 2,
  },
  gridCommonName: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
    marginBottom: 8,
  },
  gridMeta: {
    gap: 4,
  },
  ratingContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  rating: {
    fontSize: 12,
    fontFamily: 'Inter-Medium',
    color: '#1F2937',
  },
  locationContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  location: {
    fontSize: 10,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
    flex: 1,
  },
  listCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 16,
    flexDirection: 'row',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  listImage: {
    width: 80,
    height: 80,
    borderRadius: 8,
    resizeMode: 'cover',
  },
  listContent: {
    flex: 1,
    marginLeft: 16,
  },
  listName: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#1F2937',
    marginBottom: 4,
  },
  listCommonName: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
    marginBottom: 8,
  },
  listMeta: {
    gap: 4,
    marginBottom: 8,
  },
  metaItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  metaText: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
  },
  notes: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: '#374151',
    lineHeight: 16,
  },
  listActions: {
    alignItems: 'center',
    gap: 12,
  },
  favoriteButton: {
    padding: 8,
  },
  careReminders: {
    paddingHorizontal: 20,
    paddingBottom: 20,
  },
  reminderCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 16,
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  reminderIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#F3F4F6',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  reminderContent: {
    flex: 1,
  },
  reminderTitle: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: '#1F2937',
    marginBottom: 2,
  },
  reminderTime: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
  },
  reminderAction: {
    backgroundColor: '#4F7942',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 6,
  },
  reminderActionText: {
    fontSize: 12,
    fontFamily: 'Inter-SemiBold',
    color: '#FFFFFF',
  },
});